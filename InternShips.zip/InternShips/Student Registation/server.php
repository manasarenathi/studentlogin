<?php



session_start();

if(isset($_POST['submit'])){

   $conn=mysqli_connect('localhost','root','', 'interns');

   $username = mysqli_real_escape_string($conn, $_POST['username']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $password = md5($_POST['password']);
   $repassword = md5($_POST['repassword']);
   $usertype = $_POST['usertype'];

   $select = " SELECT * FROM register WHERE email = '$email' && password = '$password' ";

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){

      $row = mysqli_fetch_array($result);

      if($row['usertype'] == 'admin'){

         $_SESSION['username'] = $row['username'];
         header('location:admin.php');

      }elseif($row['usertype'] == 'user'){

         $_SESSION['username'] = $row['username'];
         header('location:home.php');

      }
     
   }else{
      $error[] = 'incorrect email or password!';
   }

};
?>





