<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HomePage</title>

    <style type="text/css">
        
        header{
            height: 40px;
            background-color:darkblue;
            padding: 40px;    
        }

        nav ul li{
            color:white;
            display: inline;
            
            padding: 20px;
            font-size: 20px;
        }
        nav ul li:hover{
            text-decoration: underline;
            cursor:pointer;
            top: -5px;
           
        }
        nav ul{
            margin-left: 50%;
        }

       
       
       .signin{
        background-color: black;
        padding: 10px;
        margin-left: 150px;
        margin-top: 50px;
        border-radius: 10px;
       }
     .signout{
        background-color: black;
        padding: 10px;
        margin-left: px;
        margin: 5px;
        border-radius: 10px;
     }
       
    </style>

</head>


    <header><nav>
        <ul>
            <li>Home</li>
            <li>About</li>
            <li>Contact</li>
            <li>Blog</li>
            <a href="login.php">
                <li class="signin">Signin </li>
            </a>
          
            <a href="register.php">
                <li class="signout">SignUp</li>
            </a>
           
           
        </ul> 
    </nav></header>
        
    
    
</body>
</html>