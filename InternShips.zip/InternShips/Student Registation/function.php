<?php



if(isset($_POST['submit'])){
 
   $conn=mysqli_connect('localhost','root','', 'interns');

   $username = $_REQUEST['username'];
   $email = $_REQUEST['email'];
   $password = md5($_POST['password']);
   $repassword = md5($_POST['repassword']);
   $usertype = $_POST['usertype'];

   $sql = " SELECT * FROM register WHERE email = '$email' && password = '$password' ";

  $result = $conn->query($sql);

   if($result->num_rows > 0){

      $error[] = 'user already exist!';

   }else{

      if($password != $repassword){
         $error[] = 'password not matched!';
      }else{
         $insert = "INSERT INTO register(username, email, password, usertype) VALUES('$username','$email','$password','$usertype')";
         mysqli_query($conn, $insert);
         header('location:login.php');
      }
   }

};


?>