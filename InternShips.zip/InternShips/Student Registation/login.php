
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link  rel="stylesheet" href="login.css"/>
</head>
<body >
   <div class="containerLogin">
    <h1>Login</h1>
    <form  action="server.php" method="POST">
       
        <div class="text_field">
            <input type="email"  name="email" id="email" idrequired>
            <span></span>
            <label>Email</label>
        </div>
        <div class="text_field">
            <input type="password" name="password" id="password" required>
            <span></span>
            <label>Password</label>
        </div>
        <div class="Pass">
          <a href="">Forgot Password?</a>
        </div><br>
        <input type="submit" value="login" name="submit">
        <div class="signup_link">
            Not a member <a href="register.php">Signup</a>
        </div>

    </form>

   </div>
    
</body>
</html>