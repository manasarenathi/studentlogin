<?php


session_start();

if(!isset($_SESSION['username'])){
    header('location: login.php');
}



?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User</title>
    <style>
        h1{
            color: darkgreen;
            font-size: 40px;
        }
        .btn{
            font-size: 30px;
            color:red;
            text-decoration: none;
           
        }
        .btn:hover{
            text-decoration: underline;
        }
        </style>
</head>
<body>
<h1>Hello 👋 <?php echo $_SESSION['username'] ?> Welcome to UserPanel...!!</h1>
<br><br>
    <a href='logout.php' class="btn">Logout</a>
    
</body>
</html>