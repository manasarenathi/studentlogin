<?php

$mysqli = mysqli_connect('localhost','root','','interns');


?>